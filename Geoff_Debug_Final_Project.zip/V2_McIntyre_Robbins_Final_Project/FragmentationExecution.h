//
// Created by Owner on 4/26/2021.
//

#ifndef SFML_TEMPLATE_FRAGMENTATIONEXECUTION_H
#define SFML_TEMPLATE_FRAGMENTATIONEXECUTION_H

#include "GameManager.h"
#include "Asteroid.h"

class FragmentationExecution {
public:
    void pushBackAsteroidVec(Asteroid fillAsteroid, GameManager& game);
};


#endif //SFML_TEMPLATE_FRAGMENTATIONEXECUTION_H
